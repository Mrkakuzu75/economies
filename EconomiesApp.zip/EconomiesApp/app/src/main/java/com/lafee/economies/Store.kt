package com.lafee.economies

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("eco", Context.MODE_PRIVATE)
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    var budget: Int
        get() = p.getInt("budget", 5000)
        set(v) = p.edit().putInt("budget", v).apply()

    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) = p.edit().putBoolean("enabled", v).apply()

    // Dépenses du jour : remises à zéro automatiquement chaque nouveau jour
    var spent: Int
        get() = if (p.getString("day", "") == today()) p.getInt("spent", 0) else 0
        set(v) = p.edit().putString("day", today()).putInt("spent", v).apply()
}
