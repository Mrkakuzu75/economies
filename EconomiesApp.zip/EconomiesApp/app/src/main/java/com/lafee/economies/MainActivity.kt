package com.lafee.economies

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = 48
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply { text = "💰 Mes Économies"; textSize = 26f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        root.addView(status)

        val budget = EditText(this).apply {
            hint = "Budget du jour (FCFA)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(store.budget.toString())
        }
        root.addView(budget)
        root.addView(Button(this).apply {
            text = "Enregistrer le budget"
            setOnClickListener {
                store.budget = budget.text.toString().toIntOrNull() ?: store.budget
                refresh()
            }
        })

        val expense = EditText(this).apply {
            hint = "Dépense (FCFA)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(expense)
        root.addView(Button(this).apply {
            text = "Ajouter la dépense"
            setOnClickListener {
                store.spent += expense.text.toString().toIntOrNull() ?: 0
                expense.setText("")
                refresh()
            }
        })

        root.addView(Button(this).apply {
            text = "1. Autoriser l'affichage par-dessus les apps"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        })

        val sw = Switch(this).apply {
            text = "2. Activer le rappel au déverrouillage"
            isChecked = store.enabled
            setOnCheckedChangeListener { _, on ->
                if (on && !Settings.canDrawOverlays(this@MainActivity)) {
                    isChecked = false
                    Toast.makeText(this@MainActivity, "Autorise d'abord l'affichage (étape 1)", Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                store.enabled = on
                val svc = Intent(this@MainActivity, UnlockService::class.java)
                if (on) startForegroundService(svc) else stopService(svc)
            }
        }
        root.addView(sw)

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        val left = store.budget - store.spent
        status.text = "Budget : ${store.budget} FCFA\nDépensé aujourd'hui : ${store.spent} FCFA\n" +
            if (left >= 0) "Reste : $left FCFA" else "Dépassement : ${-left} FCFA ⚠️"
    }
}
