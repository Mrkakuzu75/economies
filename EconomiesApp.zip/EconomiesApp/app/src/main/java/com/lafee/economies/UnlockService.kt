package com.lafee.economies

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class UnlockService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lastShown = 0L

    private val messages = listOf(
        "Avant de dépenser : en as-tu vraiment besoin ?",
        "Chaque petit achat compte. Modère-toi aujourd'hui 💪",
        "Ton futur toi te remerciera d'économiser maintenant.",
        "Attends 10 minutes avant tout achat non essentiel.",
        "Besoin ou envie ? Choisis avec sagesse.",
        "Un franc économisé est un franc gagné."
    )

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_USER_PRESENT) showPopup()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("eco", "Mes Économies", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "eco")
            .setContentTitle("Assistant d'économies actif")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        registerReceiver(receiver, IntentFilter(Intent.ACTION_USER_PRESENT))
    }

    private fun showPopup() {
        if (!Settings.canDrawOverlays(this)) return
        val now = System.currentTimeMillis()
        if (now - lastShown < 30_000) return // anti-spam : 30 s minimum entre 2 popups
        lastShown = now
        removeOverlay()

        val store = Store(this)
        val left = store.budget - store.spent
        val state = if (left >= 0) "Il te reste $left FCFA aujourd'hui"
        else "Budget dépassé de ${-left} FCFA aujourd'hui ⚠️"

        fun tv(text: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 24, 0, 24)
        }

        val btn = Button(this).apply {
            text = "J'ai compris, je modère 💪"
            setOnClickListener { removeOverlay() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(if (left >= 0) Color.parseColor("#F2065F46") else Color.parseColor("#F2991B1B"))
            setPadding(64, 64, 64, 64)
            addView(tv("💰", 56f))
            addView(tv(messages.random(), 24f, true))
            addView(tv(state, 18f))
            addView(btn)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        getSystemService(WindowManager::class.java).addView(root, params)
        overlay = root
        handler.postDelayed({ removeOverlay() }, 8000) // fermeture auto après 8 s
    }

    private fun removeOverlay() {
        handler.removeCallbacksAndMessages(null)
        overlay?.let {
            try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    override fun onDestroy() {
        removeOverlay()
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
}
