package com.lafee.economies

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Store(c).enabled) {
            c.startForegroundService(Intent(c, UnlockService::class.java))
        }
    }
}
